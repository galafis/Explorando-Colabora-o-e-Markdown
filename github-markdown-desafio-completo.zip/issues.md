# [ISSUE] Adicionar seção de Contribuição ao README.md

## Descrição
O projeto poderia ter uma seção detalhada sobre como contribuir com ele, incluindo instruções de fork, clone, criação de branch, PR e contato com o autor.

## Sugestão
Adicionar após a seção "Sobre mim".
