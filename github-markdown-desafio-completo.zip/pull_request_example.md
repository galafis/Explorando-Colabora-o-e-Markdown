# Pull Request - Atualização do README.md

## O que foi alterado
- Adicionada seção "Como contribuir"
- Corrigidos erros de digitação
- Melhorada a formatação com emojis

## Justificativa
Melhorar a clareza do projeto e incentivar colaboração aberta.
